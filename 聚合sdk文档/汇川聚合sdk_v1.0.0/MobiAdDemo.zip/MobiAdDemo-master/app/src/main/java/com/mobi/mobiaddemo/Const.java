package com.mobi.mobiaddemo;

/**
 * @author zhousaito
 * @version 1.0
 * @date 2020/7/16 15:03
 * @Dec 略
 */
public class Const {
    //3014001 / 测试开屏广告
    //3014002 / 测试信息流
    //3014003 / 测试插屏
    //3014004 / 测试激励视频
    //3014005 / 测试全屏视频

}
